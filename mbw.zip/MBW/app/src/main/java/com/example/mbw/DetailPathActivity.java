package com.example.mbw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DetailPathActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_path);
    }
}
