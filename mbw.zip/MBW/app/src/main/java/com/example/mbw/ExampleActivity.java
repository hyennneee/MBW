package com.example.mbw;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.mbw.myPageFragment.FragmentPath;
import com.example.mbw.myPageFragment.FragmentPlace;
import com.example.mbw.myPageFragment.FragmentSetting;

public class ExampleActivity extends AppCompatActivity {
    private FragmentManager fragmentManager;
    private FragmentPath fragmentA;
    private FragmentPlace fragmentB;
    private FragmentSetting fragmentC;
    private FragmentTransaction transaction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example);

        fragmentManager = getSupportFragmentManager();

        fragmentA = new FragmentPath();
        fragmentB = new FragmentPlace();
        fragmentC = new FragmentSetting();

        transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.frameLayout, fragmentA).commitAllowingStateLoss();
    }

    public void clickHandler(View view)
    {
        transaction = fragmentManager.beginTransaction();

        switch(view.getId())
        {
            case R.id.btn_fragmentA:
                transaction.replace(R.id.frameLayout, fragmentA).commitAllowingStateLoss();
                break;
            case R.id.btn_fragmentB:
                transaction.replace(R.id.frameLayout, fragmentB).commitAllowingStateLoss();
                break;
            case R.id.btn_fragmentC:
                transaction.replace(R.id.frameLayout, fragmentC).commitAllowingStateLoss();
                break;
        }
    }
}
