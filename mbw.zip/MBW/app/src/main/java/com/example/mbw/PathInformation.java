package com.example.mbw;

public class PathInformation {
        public int drawableId;
        public String price;

        public PathInformation(int drawableId, String price){
            this.drawableId = drawableId;
            this.price = price;
        }
}
